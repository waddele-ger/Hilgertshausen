# Änderungsprotokoll

## Alpha 3.2 – Kassieransicht aufgeräumt

### Neu
- Offene Tische und offener Betrag werden als gut sichtbare Statuskarte angezeigt.
- Freie Tische sind dezent grün markiert, belegte Tische weiterhin gelb.

### Verbessert
- Die Feedback-Funktion befindet sich jetzt in den Einstellungen.
- Der störende schwebende Feedback-Button wurde entfernt.
- Der Header zeigt nur noch den für das Kassieren relevanten Hinweis „Nur Barzahlung“.

## Alpha 3.1 – Verständlicher Feedback-Ablauf

### Verbessert
- Der Feedback-Button verwendet keine technischen Begriffe mehr.
- „Bericht öffnen“ wurde durch „Feedback senden“ ersetzt.
- Vor dem Absenden wird verständlich erklärt, was anschließend passiert.
- Nach dem Öffnen der vorbereiteten Meldung erscheint eine kurze Schritt-für-Schritt-Hilfe.
- Die Tester müssen nur noch gegebenenfalls die Anmeldung durchführen und auf „Submit new issue“ tippen.

# Changelog

## Alpha 3.0 – Tester Edition (2026-07-16)

### Neu
- Feedback-Button mit Käfer-Symbol
- Meldungsarten: Fehler, Verbesserung und Idee
- Freiwillige Testfragen
- Automatische technische Angaben im Bericht
- Vorausgefülltes GitHub-Issue
- Versionsanzeige und „Was ist neu?“
- Rückkehr zu Alpha 2.0 und Alpha 1.1

### Unverändert
- Tischbasierte Bestellungen
- Einzel- und Gesamtabrechnung
- Ausschließlich Barzahlung
- Lokale Speicherung und Datensicherung
