# TSV Hilgertshausen – Festkasse

Version: Alpha 3.4

## Projekt

Die Festkasse ist eine einfache, mobile Web-App für Vereinsveranstaltungen.
Sie ist bewusst keine zertifizierte Kassensoftware, sondern eine leicht bedienbare Unterstützung für Freizeitkassierer.

Der Fokus liegt auf:
- schneller Bedienung
- möglichst wenigen Klicks
- klarer Übersicht
- einfacher Fehlerkorrektur
- zuverlässiger Tagesstatistik

## Funktionen

### Kassieren
- Tische verwalten
- Bestellungen erfassen
- Zahlungen abschließen
- Tische automatisch freigeben

### Übersicht
- Freie und belegte Tische
- Offene Tische zuerst
- Anzeige offener Beträge

### Statistik
- Gesamtumsatz
- Anzahl der Kassenvorgänge
- Umsatz je Tisch
- Anzahl der Zahlungen je Tisch

### Zahlungskorrekturen
- Bereits abgeschlossene Zahlungen erneut öffnen
- Beträge korrigieren
- Fortlaufende Vorgangsnummern
- Kennzeichnung korrigierter Zahlungen
- Nachvollziehbare Korrekturhistorie

## Installation

1. Projekt auf einen Webserver oder GitHub Pages kopieren.
2. Anwendung im Browser öffnen.
3. Optional als PWA installieren.

## Bedienphilosophie

Die Startseite dient ausschließlich dem Kassieren.

Selten benötigte Funktionen befinden sich unter „Einstellungen“.

Neue Funktionen werden erst nach echtem Praxistest ergänzt.

## Dokumentation

- CHANGELOG.md
- TODO.md
- PROJECT_RULES.md

## Aktuelle Version

Alpha 3.4

Neue Funktionen:
- Statistik
- Statistik je Tisch
- Vorgangsnummern
- Bearbeiten abgeschlossener Zahlungen
- Kennzeichnung von Korrekturen
